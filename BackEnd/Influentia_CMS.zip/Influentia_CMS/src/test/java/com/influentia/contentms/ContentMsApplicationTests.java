package com.influentia.contentms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.influentia.contentms.ContentMsApplication;


@SpringBootTest(classes = ContentMsApplication.class)
class ContentMsApplicationTests {

	@Test
	void contextLoads() {
		
	}

}